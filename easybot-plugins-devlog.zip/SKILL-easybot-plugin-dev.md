---
name: easybot-plugin-dev
description: 开发、调试、集成 EasyBot（QQ 机器人 + Minecraft 桥接）V8 插件：宿主 API、WebUI 页面、AI 工具接入、配置持久化，以及一批会静默失败的坑（HTTP 服务未启动、日志占位符、页面转义、桥接顺序、动作必须同步、**宿主的 event 对象不可写**、**dotnet 反射的四种错误写法**等）。
whenToUse: 当任务涉及编写/修改 EasyBot 插件（manifest.json + 单文件 JS）、给插件加 WebUI 菜单或设置页、把插件能力注册成 AI 可调用的工具、或排查"插件不生效/页面没反应/日志缺失"这类问题时。
metadata:
  domain: easybot
  verified-on: EasyBot + ClearScript(V8) + Carpet, 真实服务器实测
---

# EasyBot 插件开发（含 WebUI 与 AI 工具接入）

本 skill 全部结论都来自真机实测（一个完整的物品寄送插件从零到上线），**踩过的坑都标了 ✗**。

## 0. 工作纪律（最重要）

1. **证据优先，不猜** ✓ —— 说"能用"之前必须有日志/命令输出/文件内容
2. **任何改动服务器设置的代码，都必须能精确还原** ✓（见 §6）
3. **排查先只读取证** ✓（日志、SQLite、存档文件），确认清楚再改代码
4. **改完必须验证** ✓（本地桩测试 + 真机日志），别只看语法通过
5. **自测必须看退出码** ✗✗ —— 我长期用 `node dev/selftest.js | tail -2`，
   **管道会把失败退出码吃掉** ✓，结果一次带致命 bug 的版本被当成"通过"直接部署了 ✗
   → 正确写法：`set -o pipefail`，或重定向到文件后判断 `$?`，或直接 grep「失败项」 ✓
6. **桩测试 ≠ 真机** ✓ —— mock 里 event 是普通 JS 对象，宿主里是 .NET 对象；
   mock 能过的东西在真机上可能一进来就抛（见 §5.12）。**凡是"宿主对象/宿主 API"的用法，
   桩测试必须刻意模拟宿主限制，否则等于没测** ✗

---

## 1. 插件形态与生命周期

- 一个插件 = 插件目录下的 `manifest.json` + 单文件入口 JS（**不能用 `require` 引宿主的模块**，但可以 `require` 自己目录下的相对文件——最稳妥是**全部写进一个文件**）
- **插件是否启用不在你的代码里** ✗：EasyBot 只把事件派发给"已启用"的插件。
  启用状态在 `/app/appdata/dp/plugin/toggle.json`（`{"toggle":{plugin_id:true}}`）。
  **症状：插件加载成功、有启动日志，但收不到任何事件** → 九成是这里缺你的 plugin_id ✗
- 常用事件：`bus.on('enable'|'disable'|'group_message_event'|'direct_message_event'|'menu_ready'|…)`
- **`enable` 之后**才开始收业务事件 ✓；初始化（起 HTTP、注册工具、注册菜单）都放 `enable`
- 热重载/重复 enable 会**重复执行** → 幂等保护（`if (_serverId) return true;` 之类）

## 2. 宿主全局 API 速查

| 全局 | 用途 | 备注 |
|---|---|---|
| `bus` | 事件 | `bus.on(name, fn)` |
| `logger` | 日志 | `info/warning/error`；**占位符坑见 §5.2** |
| `litedb` | 键值存储 | `Get/Set(scope, key)`；可 `GetDbPath()` |
| `db` | 玩家/社交账号 | `db.GetPlayerByName(name)`、`db.GetSocialAccount(platform, uuid)` |
| `sessions` | 服务器桥接 | `sessions.GetBridges()` |
| `httpServer` | 起 HTTP 服务 | **必须调 `StartServerAsync` ✗✗（§5.1）** |
| `network` | HTTP 客户端 | `network.post(url, body)`；**★ Content-Type 恒为 text/plain ✗（§5.10）** |
| `dotnet` | .NET 反射 | `dotnet.System.IO` 用于读写文件 |
| `MessageChain` | 发消息 | `new MessageChain().Text(str)` |

桥接对象：
```js
const b = sessions.GetBridges()[i];
b.Session.Info.CachedServerName        // 服务器名
b.Session.Info.CachedServerToken       // 服务器令牌
await b.SendRunCommandAsync('', cmd, false);   // 以控制台(4级权限)执行; 第1参只对 PAPI 有意义
await b.ReadNbtData(uuid, NbtDataType.PlayerData);
```

**NbtDataType 枚举取法**（类型名不在全局）：扫 `AppDomain.CurrentDomain.GetAssemblies()` 找
`EasyBot.Bridge.Packet.Client.NbtDataType`，再 `Enum.Parse(t,'PlayerData')`。

## 3. WebUI 接入（菜单 + 设置页）

宿主在菜单系统就绪时把 `pluginMenu` 通过事件给你：

```js
bus.on('menu_ready', function (pluginMenu) { registerWebUI(pluginMenu); });

function registerWebUI(pluginMenu) {
    pluginMenu.registerGroup('my_plugin', '我的插件', 'MailOutlined', null, true, 61, false);
    pluginMenu.register(
        'settings',                       // pageId
        '/pages/my_plugin/settings',      // 路径
        '我的插件 设置',                   // 标题
        'SettingOutlined',                // AntD 图标名
        onAction,                         // ★ 动作处理函数
        settingsHtml,                     // ★ 返回 HTML 的函数(不是字符串!)
        'my_plugin',                      // groupId
        true, null, false,
        '设置说明'
    );
}
```

页面里的桥接（**宿主注入的，不一定什么时候就绪** ✗）：
```js
window.webuikit.action(method, params)   // 返回结果；插件侧收到 onAction({method, parameters})
```

### ★ 三条铁律（都是实测踩出来的）

1. **`onAction` 必须是同步函数** ✗✗
   返回 Promise 时宿主**可能拿不到结果** → 页面永远停在"加载中"。
   → 需要服务器数据的，**后台缓存**（定时刷新），动作只读缓存。
2. **不要在动作里 `await` 桥接调用** ✗
   会出现"日志里连命令都没打出来，页面就一直转"。
   → 后台刷新 + 超时 + 页面轮询。
3. **页面源码字符串里的 `\n` 必须双写** ✗✗✗
   生成页面 JS 时写 `'...join("\n")'` → JS 会把它变成**真换行** → 页面脚本**语法错误** →
   **整个 `<script>` 不执行** → 症状是"**点按钮没反应**"，而且**控制台之外毫无提示**。
   → 文件里写 `'...join("\\n")'`。

### 页面模板骨架

```js
function settingsHtml() {
  return [
    '<!DOCTYPE html><html lang="zh-CN"><head><meta charset="utf-8">',
    '<style>body{margin:0;padding:20px;font-family:-apple-system,"Microsoft YaHei",sans-serif;background:#f5f6f8}',
    '.card{background:#fff;border-radius:10px;padding:14px 18px;margin-bottom:12px}</style>',
    '</head><body>',
    '<h1>标题</h1><div class="card">…表单…</div>',
    '<div class="card"><span id="msg" class="muted"></span></div>',
    '<script>',
    'function $(id){return document.getElementById(id)}',
    'function call(m,p){try{if(!window.webuikit||typeof window.webuikit.action!=="function")',
    '  {return Promise.reject(new Error("页面桥接还没就绪, 请刷新页面"))}',
    '  return Promise.resolve(window.webuikit.action(m,p||{}))}catch(e){return Promise.reject(e)}}',
    // ★ 等桥接就绪再跑初始化, 否则第一次进入会报 "reading 'action' of undefined"
    'function whenReady(cb){if(window.webuikit&&typeof window.webuikit.action==="function"){cb();return}',
    '  var n=0;var t=setInterval(function(){if(window.webuikit&&typeof window.webuikit.action==="function")',
    '    {clearInterval(t);cb()}else if(++n>24){clearInterval(t)}},250)}',
    'function doLoad(){try{call("load").then(function(r){ /* 填表单 */ },function(e){$("msg").textContent="读取失败: "+e})}catch(e){}}',
    'whenReady(doLoad);',
    '</script></body></html>'
  ].join('\\n');     // ← ★ 这里也必须是 \\n
}
```

### 验证页面的方法（一定要做）

把生成的 `<script>` 抽出来，用**桩 DOM** 真跑一遍：

```js
const js = (settingsHtml().match(/<script>([\s\S]*)<\/script>/)||[])[1];
try { new Function(js); console.log('语法 ✓'); } catch (e) { console.log('语法 ✗', e.message); }
// 再模拟 window.webuikit / document.getElementById 跑一次, 看点击保存会不会真的调 action('save')
```
**这个测试就是"页面按钮没反应"类 bug 的唯一可靠发现手段** ✓

## 4. 把插件能力注册成 AI 工具

宿主（AI 插件）暴露一个工具网关（默认 `http://127.0.0.1:20777`）：

```js
// 主动注册(带重试! 插件加载顺序不确定)
await network.post('http://127.0.0.1:20777/register', JSON.stringify({
  plugin: PLUGIN_ID,
  tools: [{
    name: 'my_tool',
    description: '给模型看的说明',
    parameters: { type:'object', properties:{...}, required:[...] },
    callback: { type:'http', url:'http://127.0.0.1:18888/tool/my_tool' }
  }]
}));
```
也可以在自己插件目录放 `ai-tools.json`（`{tools:[...]}`）让 AI 插件扫描发现（顺序不确定时不如主动注册）。

### 关键机制

- AI 插件调用你的 HTTP 工具时，POST 的 body 是：
  ```json
  { "tool":"...", "arguments":{...}, "context":{ "sessionKey","senderId","senderName","peerId","kind" } }
  ```
  → **`context.senderId` 是"谁在请求"**，由 AI 插件从消息事件填，**模型伪造不了** ✓
  这是做权限判断的**唯一可信来源**（不要接受模型传的"我是谁"）
- **HTTP 工具必须同步返回结果** ✗（EasyBot 的 HTTP handler 里 `await` 之后写的响应体是空的）
  → 长任务用「**发起 + 查询**」两个工具：发起立刻回 `{taskId}`，另一个工具用 taskId 查结果，
    并在工具描述里写明"等约 N 秒后再查"
- 自己的 HTTP 服务：`httpServer.CreateServer(port, name, '127.0.0.1')` → `OnPost` → **`StartServerAsync(id)`** ✗✗

## 4.5 依赖预检：缺依赖要"最先失败、且什么都不碰"

插件的功能依赖别的模组/插件时(SKILL: minecraft-fakeplayer-item-ops 里那些命令),
**不要跑到一半才发现缺东西** ✗ —— 那会留下残留, 或者报一句看不懂的错。

正确模式(实测有效):
```js
var _capsCache = {};
async function checkServerCaps(server) {            // 结果按服务器缓存(如 10 分钟)
    const probe = async function (cmd) {
        const r = await runCmd(server, cmd);
        // 只有"命令不存在"算缺失; Incorrect argument / 需要玩家 等都证明命令存在
        return !/unknown or incomplete command|unknown command|command not found/i.test(r.text || '');
    };
    return { carpet: await probe('carpet <某规则>'), mail: await probe('mail list') };
}
// 放在"读存档/算目标/改设置"【之前】, 不通过就 throw 一句人话
```
★ 探针必须**带参数且无副作用**, 绝不能敲裸命令(详见 minecraft skill §5.4 的实测反例 ✗)。

## 5. 会静默失败的坑（每个都真实踩过）

### 5.1 HTTP 服务：只注册路由**不会监听端口**
```js
const sid = httpServer.CreateServer(port, name, '127.0.0.1');
httpServer.OnPost(sid, '/tool/x', handler);
await httpServer.StartServerAsync(sid);     // ★ 少了这行: 路由登记了, 端口没监听, 请求全失败
```
判据：`/proc/net/tcp` 里没有你的端口；或容器内 `wget` 没反应。

### 5.2 日志占位符数量不匹配 → **整条日志消失**
```js
logger.info('...{0}... {0}...', oneArg);     // ✗ 这条日志会静默不见
logger.info('...{0}... {1}', a, b);          // ✓
```
**排查任何"代码明明执行了却没日志"时，先查占位符 ✗**

### 5.3 Minecraft 颜色码要整对删除
控制台输出含 `§x` **十六进制**格式 → 必须 `/§[\s\S]/g` 全删；
用 `/§[0-9a-fklmnor]/` 会漏，导致后续解析（槽位、设置值）全错 ✗

### 5.4 插件之间**没有**进程内调用
只能走 HTTP / 工具注册 / 共享文件。所以"让另一个插件干活"必须设计进程外契约。

### 5.5 配置的三层优先级 → 保存必须同时写
常见实现：`默认值 → 插件目录 config.json → litedb 覆盖`。
**只写 config.json，会被 litedb 里的旧覆盖挡住，UI 改了不生效** ✗
→ 保存时**同时**写文件与 litedb；并且**新增配置键必须同时加进默认值表** ✗
（否则 `if (k in defaults)` 这类合并逻辑会**静默跳过**它的保存 ✗）

### 5.6 不要写死插件目录/端口（而且别盲信 GetDbPath）

写死 `/app/appdata/plugins/<插件id>/` ✗：使用者**改了插件文件夹名就崩** ✗。

但**也不能只信 `litedb.GetDbPath()`** ✗✗：实测有的 EasyBot build 它返回的是
**共享数据目录**（如 `/app/appdata/data` ✓ 里面放的是各插件的 `.ldb`），**不是你的插件目录** ✗ ——
照着它算路径会把配置**读写到别处** ✗（我在真机上踩过：日志里出现
`插件目录=/app/appdata/data` ✗，并在那儿写出了一个多余的 `ai-tools.json` ✗）。

**正确做法：候选路径 + 取第一个真实存在的** ✓
```js
var _cfgPathCache = null;
function configCandidates() {
    const id = PLUGIN_ID, out = [];
    try {
        const raw = String(litedb && typeof litedb.GetDbPath === 'function' ? litedb.GetDbPath() : '');
        if (raw) {
            const base = raw.replace(/[\\/][^\\/]*$/, '');        // 去掉文件名
            out.push(base + '/' + id + '/config.json');             // {base}/{id}/config.json
            out.push(base + '/plugins/' + id + '/config.json');     // {base}/plugins/{id}/config.json
            out.push(base + '/config.json');                        // 万一 base 就是插件目录
        }
    } catch (e) { }
    out.push('/app/appdata/plugins/' + id + '/config.json');        // 约定路径(兜底/创建位置)
    return out;
}
function configPath() {
    if (_cfgPathCache) return _cfgPathCache;
    const c = configCandidates();
    for (let i = 0; i < c.length; i++) if (fileExists(c[i])) return (_cfgPathCache = c[i]);
    return (_cfgPathCache = c[c.length - 1]);                       // 都不存在 -> 在约定位置创建
}
function pluginDir() { return configPath().replace(/[\\/][^\\/]*$/, ''); }
```
**启动日志里把推导结果打出来** ✓（`路径: 插件目录=… config=… 工具端口=… 网关=…`）——
这次就是靠它一眼发现指错了地方 ✓。

端口/外部地址同理：做成配置项 + 默认值保守 + 启动日志打印实际生效值。

### 5.7 桥接顺序不确定
`sessions.GetBridges()` 返回顺序**不保证**（多台服时每次可能不同）。
→ 需要"某一台"时要显式匹配名字/令牌；展示状态时**列出全部**。

### 5.8 插件常常比 MC 服务器先就绪
启动瞬间 `GetBridges()` 可能为空（甚至**抛异常**"没有已连接的服务器"）。
→ 必须**自动重试**（15 秒一次那种），重试分支别忘了 `catch`（异常路径和返回空是两条路 ✗）

### 5.10 `network.post` 发出的 Content-Type 恒为 `text/plain` ✗✗

宿主把 Content-Type 归在 content 上，而 `RequestMessage` 只暴露 url/method/headers/body，
所以 **`network.post` 永远是 `text/plain`** ✗ —— 调**严格校验的应用接口**（比如 Tavily）会直接 400：

```
[{"type":"model_attributes_type","loc":["body"],
  "msg":"Input should be a valid dictionary or object to extract fields from",
  "input":"{\"api_key\":…}"}]        ← 服务端把 body 当成【字符串】而不是对象
```

对本机的 AI 网关（`/register`）无所谓（它自己解析字符串 ✓），但外部 API 一律要小心 ✗。

**解法：用 `dotnet` 反射调原生 .NET HttpClient**（实测可用，见 ai-chat 的 `lib/httpclient.js`）：
```js
const asm = dotnet.System.Reflection.Assembly.Load('System.Net.Http');
const HttpClientT = asm.GetType('System.Net.Http.HttpClient');
const StringContentT = asm.GetType('System.Net.Http.StringContent');
// 找 3 参构造 (string, Encoding, string)
const ctor = StringContentT.GetConstructors().find(c => c.GetParameters().length === 3);
const client = dotnet.System.Activator.CreateInstance(HttpClientT);
const content = ctor.Invoke([body, dotnet.System.Text.Encoding.UTF8, 'application/json']);   // ★ 关键
const resp = await client.PostAsync(url, content);        // 失败兜底: task.GetAwaiter().GetResult()
const text = await resp.Content.ReadAsStringAsync();
```

### 5.11 HTTP handler 里 `await` 之后写的响应体是**空的** ✗✗

（这条 §4 也提过，但值得单独强调 —— 我因此白改了两版）
```js
httpServer.OnPost(sid, '/tool/x', async (req, res) => {           // ✗ async handler
    const r = await someAsync();
    return aiWrite(res, 200, r);                                  // 响应体是空的
});
```
症状：**curl 得到 0 字节**，而且 handler 里的第一行日志**根本不出现** ✓ →
说明宿主**没执行** async handler ✗。

正确做法只有两条：
- **同步 handler + 立刻写完响应** ✓
- **长任务 → 「发起 + 查询」两个工具**（§4）✓：发起立刻回 `{taskId}`，另一个工具按 taskId 取 ✓

**排查手法**：在 handler 第一行打日志 ✓ —— **日志不出来 = handler 没被执行** ✓（比看响应快）。

### 5.12 绝对不能往宿主的 `event` 对象上写属性 ✗✗✗（代价：AI 全线停摆 36 分钟）

```js
event.__hasFile = true;   // ✗ 真机直接抛：
// The object has no suitable property or field named '__hasFile'
```
- `event` 是宿主（.NET / ClearScript）对象，**只读**，不能挂 JS 属性 ✗
- 更狠的是它在**每条消息的必经路径**上 → 一抛，**所有消息全部失败**，AI 完全不回 ✗
- 桩测试里 event 是普通对象 → 写属性完全正常 → **自测 485 项全过** ✗（这就是漏网的原因）
- 而且这个错我**犯过两次** ✗：第一次是变量作用域（`_hasFileContent is not defined`），
  第二次是往 event 上写（本条）—— 两次都是"自测绿、真机炸" ✓

正确做法：
- **参数传递** ✓：`respond(event, kind, key, text, decision, hasFile)`
- 或用**模块级 Map**（按 sessionKey 键）✓；**绝不写回 event** ✗
- **回归测试** ✓：`Object.freeze(event)` 或 `new Proxy(ev, { set(){ throw new Error('不能写 event') } })`
  再发一条消息，断言"没有出现「群消息处理失败」" ✓
- ★ **还要验证这条测试真的会红** ✓：把 bug 放回去跑一遍，确认"失败项 +1"（我就这么做了一次，
  才发现之前的测试其实测不到东西）✓

排查判定：日志出现 `群消息处理失败: The object has no suitable property or field named 'xxx'` → 就是这条 ✗

### 5.13 `dotnet` 反射：四个"看着对、真机必炸"的写法 ✗✗

一个"读 zip 里的文本"功能，连续炸了 4 次才通 ✓：

| 写法 | 真机结果 | 正确写法 |
|---|---|---|
| `File.WriteAllBytes(path, byte[])` | `The best overloaded method match ... has some invalid arguments` ✗ | **别拿 byte[]**：`WebClient.DownloadFile(url, path)` 直接落盘 ✓ |
| `Type.GetMethod('OpenRead', [strType])` | 被解析成 `GetMethod(string, BindingFlags)` ✗ | **遍历 `GetMethods()`**，按 `Name` + `GetParameters().length` 找 ✓ |
| `entries.get_Item(i)` / `entries[i]` | 取不到条目（静默跳过）✗ | `entries.GetEnumerator()` + `while (it.MoveNext()) it.Current` ✓ |
| 解压后"一个条目都没匹配" | 先怀疑正则，其实是遍历没拿到 ✗ | 先把**条目名打进日志**（`共 {0} 个条目; 前几个: {1}`）✓ |

两条实测纪律：
- **本地把文件下下来亲眼看看** ✓ —— 我用缓存里的 URL 把用户的 zip 下到宿主机，`unzip -l` 一看
  里面 7 个文本条目 → 立刻排除"文件不对"，锁定"我的遍历错" ✓（比让用户再发一次强得多）
- **同步 vs 异步**：`WebClient.DownloadFile` 同步 ✓；`HttpClient.PostAsync` 要 `await task`，
  失败兜底 `task.GetAwaiter().GetResult()` ✓

### 5.14 宿主自身的命令超时改不了
`SendRunCommandAsync` 超时（实测约 6 秒）由 EasyBot 内部固定。
→ 插件只能：自己设更短上限 ✓、对**只读命令**自动重试 ✓、对**写命令绝不重试**（避免重复执行）✗

## 6. 调试与取证工具箱

- **日志会滚动归档**：`/app/logs/latest.log`（当前）+ `*.logs.zip`（历史）→ 查旧事要 `unzip -p`
- **QQ 消息文本开头的 QQ 号通常是"被引用消息的作者"，不是发送者** ✗✗
  → 自己插件里务必记录 `event.SenderId`（我就因为没记而误判过发送者）
- **EasyBot 数据库（SQLite）是权威绑定关系来源**：
  ```bash
  docker cp <容器>:/app/appdata/EasyBot.db /tmp/eb.db   # 连同 -wal/-shm
  python3 -c "import sqlite3;c=sqlite3.connect('file:/tmp/eb.db?mode=ro',uri=True);print(c.execute('select name from sqlite_master where type=\"table\"').fetchall())"
  ```
  表：`Player(Name,Uuid)` / `SocialAccount(Platform,Uuid,Name)` / `PlayerSocialAccount(SocialAccountsId,UsersId)`
  → "某个 QQ 绑了哪个游戏账号"这种问题**只能**查这里，别靠推断
- **确定性验证**：把生成的页面脚本/纯函数抽出来，用**桩数据真跑**（别只做语法检查）
- 只读复制数据库/存档来查，**绝不直接改** ✓

## 7. 安全设计模式（做"会真的动东西"的插件时照抄）

```
① 调用者身份只能来自宿主事件/工具 context, 绝不接受模型或文本里的"我是谁"
② 敏感操作前做"来源判定": 只允许操作用户【自己】绑定的对象
     - 提到别人 ✗ → 拒绝并解释
     - 认不出来源 ✗ → 拒绝（绝不默认成"自己的"）
③ 引用/回复触发的消息一律不执行指令（内容可能是旧消息）
     - 记录上下文 ✓ 但不动作 ✓
④ "发起 + 查询"两段式, 让 LLM 不会阻塞; 结果用结构化字段返回
⑤ 服务器设置: 只临时改 + 精确还原 + 校验 + 失败大声报警
⑥ 工具描述里写清"不要问用户 XX、不要替别人操作", 减少模型自作聪明
```

## 8. 交付前自检清单

```
[ ] enable 之后才收事件; 插件在 toggle.json 里已启用
[ ] httpServer 调了 StartServerAsync, 端口真的在监听
[ ] 所有 logger 占位符数量与参数一致
[ ] WebUI 动作是同步函数; 页面初始化等桥接就绪; 页面字符串里 \n 双写
[ ] 页面脚本用桩 DOM 真跑过(语法 + 点击流程)
[ ] 新增配置键已加入默认值表; 保存同时写文件与 litedb
[ ] 长任务用 taskId + 查询工具; 工具描述写了"何时该问用户"
[ ] 会改服务器设置的路径: 精确还原 + 校验 + 失败告警
[ ] ★ 不只是 node --check —— 要【真正加载一遍模块】:
      给宿主全局打桩(bus/logger/sessions/db/litedb/dotnet), 然后 require 它。
      node --check 只查语法, 查不出 "module.exports 引用了未定义的函数" 这类会在
      真机上直接崩掉的错误(我踩过: 一次替换因锚点不匹配静默失效, 语法检查照样通过 ✗)。
[ ] 改代码用脚本批量替换时, 【每处都要断言替换生效】(assert s2 != s), 否则会静默什么都不做 ✗
[ ] 版本号不要在代码里写死 —— 启动时读插件目录的 manifest.json, 永不与 manifest 不一致 ✓
[ ] ★★ 部署/重启【之前】先查有没有"等待玩家回复"的内存态:
      `docker restart` 会清掉进程内的 pending(选服务器/选账号/选物品) →
      玩家正卡在"回个序号就行"那一步, 重启后他回的序号【没人接】, 表现就是"没完成" ✗
      (我因此把用户的一次寄送弄丢过 ✗)。部署前先 grep 日志看有没有待选/正在跑的痕迹, 或干脆问一声。
[ ] 真机跑一遍, 并在日志里确认关键步骤都打出来了
```

## 9. 把"宿主机能力"接进容器插件（DSH 桥接模式，实测跑通）

插件在容器里、能力在宿主机上（如 `dsh` CLI、脚本、文件系统）时，**不要试图在容器里装一份** ✗，
而是宿主机起一个小 HTTP 服务，插件当客户端 ✓。

### 9.1 容器怎么找到宿主机
- 容器里**没有 `ip` 命令**也别慌：`cat /proc/net/route` 第 2 行 `Gateway` 是十六进制小端
  （`010012AC` → 0xAC120001 → **172.18.0.1**）✓
- 或者 `docker inspect <容器> --format '{{range $k,$v := .NetworkSettings.Networks}}{{$k}} gw={{$v.Gateway}}{{end}}'` ✓
- `host.docker.internal` 在纯 Linux docker 上**解析不到** ✗（别只写它）

### 9.2 桥接服务设计（可直接照抄 /home/user/dsh-bridge/bridge.mjs）
```
监听 0.0.0.0:PORT
  ✓ 来源网段白名单（127./172.17./172.18./172.100.）—— 只有容器能进
  ✓ X-DSH-Token（timingSafeEqual 比较）
  ✓ 并发限 1 + 有界队列（别让群里一句话把宿主机打满）
  ✓ 超时 SIGKILL 整个进程组（spawn 时 detached:true，kill(-pid)）
  ✓ 工作目录白名单
  ✓ 日志落文件（谁在什么时候跑了什么、耗时、输出长度）
```

### 9.3 `dsh headless` 的非交互用法（实测）
```bash
dsh headless --json "任务"                 # NDJSON 事件流
dsh headless --json --session-id <id> "继续"  # 续传同一会话（= 连续对话）
```
事件里只关心三种：
- `{"type":"session","sessionId":"session-…","cwd":"…"}` → 记住 sessionId ✓ **和真实工作目录 cwd** ✓
  （想让用户看到"在哪个目录跑"，就把 cwd 透传到结果/页脚/日志里 ✓）
- `{"type":"status","phase":"step_end","usage":{…}}` → 用量
- `{"type":"final","text":"…"}` → **最终答案**（没有 final 就说明失败）

**凭证**：headless profile 不认 web 页里配的 key，会报
`MISSING_CREDENTIAL: … store DEEPSEEK_API_KEY … or export DEEPSEEK_API_KEY` ✗
→ 从 `~/.dsh/.credentials.yaml` 的 `refs.DEEPSEEK_API_KEY` 取出来，作为**子进程环境变量**注入 ✓
（别把 key 写进代码/仓库 ✗）

### 9.4 需要"管理员确认"的动作怎么做
组合 §4 的「发起 + 查询」与 §7 的身份铁律：
1. 工具 `xxx_run` **只创建待确认请求**，立刻返回 `{status:'pending', code, requestId}` ✓（绝不执行 ✗）
2. 把确认请求发到**当前会话**：「管理员回复：同意 <code>」
3. 命令/文本里匹配 `同意 <code>`：**先查是否真有这个待确认请求**（否则普通聊天里的"同意 xx"会被误拦 ✗），
   再用 `permissions.levelOf({senderId,senderRole,peerId})` 校验等级 ≥ N ✓
4. 批准后**异步执行**，结果写回请求对象；工具 `xxx_result` 供模型轮询 ✓
5. 超时自动取消并通知 ✓；拒绝/失败都要把原因说清楚 ✓

### 9.5 又一个"自测绿、真机炸"的坑：批量插入时照抄了不存在的变量 ✗
我把同一段调用同时插进 `onGroupMessage` / `onDirectMessage`，两边都写了 `handleX(event, kind, text)`，
但这两个函数**没有 `kind` 形参**（`kind` 只在 `respond` 里）→ 每条消息都抛 `kind is not defined` ✗。
教训：**批量插入后逐个核对函数签名/作用域** ✓；并且自测要覆盖"普通消息能正常走完" ✓
（这次就是 506 项自测里的基础对话用例当场挂掉 ✓）。

### 9.6 合并转发（Node）不是每个 EasyBot 版本都有 ✗ —— 必须运行时探测 + 回退

官方文档：`MessageChain.Node(id, name, userId, chain)` **v0.4.0 新增**
（https://docs.inectar.cn/docs/easybot/develop/plugin/sdk/robot/message-chain/ ✓）

但**当前线上 build 没有** ✗（实测）：
```js
const c = new MessageChain();
typeof c.Node      // undefined
c.Node('n1','名字','10000', new MessageChain().Text('x'))
                   // TypeError: c.Node is not a function
```
另外 `NodeSegment` 全局类虽然存在，但**它不是 `Segment`** —— `chain.Add(new NodeSegment())` 会报
`The best overloaded method match for 'MessageChain.Add(Segment)' has some invalid arguments` ✗
（别被它误导）

**正确姿势：能力探测 + 优雅回退** ✓
```js
function canMergeForward() {
    const MC = Function('return (typeof MessageChain !== "undefined") ? MessageChain : null')();
    return !!(MC && typeof (new MC()).Node === 'function');
}
// 支持 → new MessageChain().Node(...) 若干节点一次发出
// 不支持 → 回退成一条带标题的长文本（功能不能因此坏掉 ✗）
```
并且**启动日志把结论打出来**（`合并转发=支持 / 不支持(回退长文本)`）✓ —— 换版本/换机器一眼可见 ✓

### 9.6.1 合并转发不可用时的替代：渲染成图片 ✓

宿主自带 `puppeteer`（实测可用：`renderHtml(html, 25, 360, 120)` → 592ms 返回 base64 PNG，
前缀 `iVBORw0KGgo` ✓）。做法：
```js
const b64 = await puppeteer.renderHtml(html, 30, 760, estHeight);   // 返回 base64(无前缀)
await sendChain(event, kind, new MessageChain().Image('base64://' + b64));
```
- 高度要自己**估算**（行数 × 字号 × 行距 + 标题 + 内边距），否则容易截断 ✓
- 长文按字/行切页，多张图分别发 ✓
- 图片样式（背景图、字体、字号、颜色、宽度、内边距、自定义 HTML 模板）全部走配置 ✓
- **给一条 `!xxx preview` 命令**：让用户自己发一张样图确认好不好看 ✓（比我盲猜 CSS 强）
- 兜底链：合并转发 → 图片 → 文本，任何一步失败都往下走，不能整条消息丢掉 ✗

### 9.6.2 `puppeteer.renderHtml` 的两个坑：**第一次忽略宽高** + **白底露边** ✗✗

实测（同一份 HTML，连续调用 4 次，量 PNG 的 IHDR）：
```
第 1 次 → 800×600   ← 浏览器刚启动，宽高参数被忽略 ✗
第 2 次 → 760×360   ✓
第 3 次 → 760×360   ✓
第 4 次 → 760×360   ✓
```
⇒ **必须先做一次"预热渲染"（丢弃结果）**，之后尺寸才听参数 ✓
```js
let warmed = false;
async function warmUp(P, img) {
    if (warmed) return;
    await P.renderHtml('<html><body style="margin:0;background:#000"></body></html>', 20, img.width, 60);
    warmed = true;
}
```

第二个坑：`body` 默认**白色**，内容比画布短时 → **右侧/底部大白边** ✗（用户当场就发现了）
修法（两招一起用）：
```css
html,body{margin:0;width:100%;min-height:100%;background:<底色或背景图 cover>}
.w{width:100%;min-height:100vh;box-sizing:border-box;padding:...}
```
⇒ **不靠"算高度"**：高度参数在这套宿主里不稳定（有时听、有时自动贴合内容），
把它只当"下限"，靠 **背景铺满 + 卡片撑满视口** 保证任何尺寸都不露白边 ✓

**怎么自己验收**（别让用户当小白鼠 ✗）：把渲染出的 base64 用 `File.WriteAllText` 写成 `.b64.txt` 到
`/app/logs/`（该目录挂载到宿主机），宿主机上 base64 解码成 png，然后**直接看图** ✓
（注意：`File.WriteAllBytes(path, byte[])` 在宿主里传参过不去 ✗，只能写文本 ✓）

### 9.7 用官方文档核实 SDK 能力，别只靠猜
`docs.inectar.cn/docs/easybot/develop/plugin/sdk/…` 有 MessageChain / Segments / AdapterContext 等页面，
比反编译 / 试探快得多 ✓（这次就是文档先确认有 `Node`，再实测发现当前 build 没有 ✓）。

### 9.7.1 私聊（DM）里用插件命令的两个前提 ✗

EasyBot 本身支持私聊 ✓（适配器有 `SendDirectMessageAsync`、插件有 `onDirectMessage` 链路），但实测踩到两点：
1. **白名单**：`access.allowDirectUserIds` 为空数组=放行 / 非空=白名单。
   若里面是占位符（如 `['__disabled_during_test__']`）→ **谁都不许** ✗，而且这层在命令处理**之前**，
   连 `!xxx` 都没反应 ✗（排查时先看这一层）
2. **权限等级**：私聊里**没有"群主/群管理员"身份** ✗ → `groupOwnerLevel/groupAdminLevel` 不生效，
   必须用 `permissions.userLevels = "QQ:3"` 显式授权 ✓（否则命令一律"权限不足"）

另外 `behavior.replyToDirect=false` 只关"普通 AI 对话"，**不影响** `!xxx` 命令 ✓
（命令在 `decideReply` 之前处理）—— 想"只开命令、不开闲聊"就这么配 ✓

### 9.7.2 DSH 的「工作区」是 Web 端概念，headless 不会自动登记 ✗

`~/.dsh/storages/workspace.json` 结构（实测）：
```json
{"unit":{"name":"workspace","version":2},
 "global":{"initialized":true,"workspaceIds":["<id>"],"archivedSessionIds":[],"pinnedSessionIds":[]},
 "tables":{"workspaces":{"<id>":{"path":"/home","title":"home","sessionIds":["session-…"],"createdAt":"…","updatedAt":"…"}}}}
```
- `dsh headless` **只**把会话写进 `~/.dsh/storages/session_projcache/sessions/<id>.json` ✓，
  **不会**写进 workspace.json ✗ → 界面上落在「**未分组**」
- 想让 headless 会话出现在某个工作区：把 `sessionId` **追加**到该工作区 `sessionIds` ✓
  - **原子写**（写 tmp → rename）+ 每次写前 `copyFileSync` 存 `.bak` ✓
  - 新工作区 id 用 `crypto.randomUUID()`，`path` 要过白名单校验 ✓
  - GUI 也在写这个文件 → 极小概率互相覆盖，能接受（下次运行再登记一次即可）✓
- DSH Web 的 `/api/*` 要鉴权（`/api` 全 401 ✗），插件端**不能**用 HTTP 登记，只能在桥接侧改文件 ✓

### 9.7.3 **headless 只能接续"没有 agentPreset"的会话** ✗✗（血泪）

在网页里开的会话，`record.rows.agentPreset.val = "standard"`；机器人用 `dsh headless --session-id` 去接会直接报：
```
dsh: session "session-…" runs under agent preset "standard",
     which the one-shot runner does not compose
```
源码 `@deepseek-ai/dsh-headless/lib/index.js` 的 `assertAdoptable()` 是**硬判断**（`preset !== undefined` 就抛），
**没有 CLI 参数能绕** ✗。另外它还会拒：`origin === "subagent"`、有 `parentSession`、`cwd` 缺失的会话。

判据（读 session 文件）：
```js
const ap = record.rows.agentPreset;            // {val: "standard"} 或 {val: null} 或缺失
const adoptable = !(ap && ap.val);             // true 才能被 headless 接续 ✓
```
产品化做法：列表里标 `✓ 可接续` / `✗ 网页会话(接不了)`，选中不可接续的**直接解释原因**，
而不是把 CLI 报错原样甩给用户 ✗。

### 9.7.4 想"续用网页会话"？读它的日志做【上下文继承】 ✓

网页会话 headless 接不了（见 9.7.3）✗，但可以**读**它的事件日志，把历史压成摘要喂进新会话 ✓：

- 事件日志：`~/.dsh/sessions/<--cwd-->/session-<id>/session.v4.jsonl.zstd`
  （目录名规则：`/home/user` → `--home-user--`；不确定就遍历 `.dsh/sessions/*/session-<id>` ✓）
- **多帧 zstd 拼接**：19MB 里 1.1 万个 zstd 魔数；`zlib.zstdDecompressSync(整个文件)` **只解第一帧** ✗
  → 按魔数 `28 b5 2f fd` 扫描，逐个 `zstdDecompressSync(data.subarray(off))`，
    解压失败的（假魔数）跳过 ✓；只看尾部 N MB 就够（要更多再放大窗口 ✓）
- 事件类型（JSONL）：`user/message`、`assistant/message`（content 里 `type:"text"` 才是正文，
  `reasoning` / `tool-call` 是噪音 ✗）、`tool/result`、`turn/start|end`、`compaction/prune` …
- 摘要：只留"用户：…/助手：…"，**从最新往回取**凑到 maxChars（保最近上下文 ✓）
- 灌进新会话：把摘要作为**首条 prompt**，并明确要求"只回复已了解上下文，不要执行任何操作" ✓
  （否则模型会把历史里的指令当新任务去执行 ✗）

### 9.7.5 MCSManager 的容器是 `--rm` 的：**别 `docker restart`** ✗✗

实测事故：`docker restart riyue-create` → 容器停下来的瞬间被自动删除 ✗
→ `No such container`、端口不通、**服务器直接没了** ✗（我用了 10 分钟才从 MCSManager 的实例配置重建回来）

正确做法 ✓：
- 想重启 MC 服：用 **MCSManager 面板/接口**（它自己创建+管理容器）✓
- 或者先 `docker inspect` 存下参数，用 `docker run` **重建**（**别带 `--rm`** ✓，否则下次还会消失 ✗）
- 重建参数从实例配置里取：`/opt/1panel/apps/mcsmanager-daemon/.../data/InstanceConfig/<id>.json`
  → `docker` 段（image / ports / memory / networkMode / workingDir / env）+ `startCommand`（`/app/start.sh`）+ `cwd`（挂到 `/app`）✓

### 9.7.6 换 MC 服务器令牌（serverToken）要动两端 ✓

`serverToken` 泄露后轮换：
1. EasyBot 侧：SQLite `EasyBot.db` → `ServerInfo.Token`（按 `Id` 对应哪台服）✓
   - 改前先 `docker stop easybot`（WAL 模式，边跑边改不安全 ✗），改完再 start ✓
2. MC 服侧：`<服目录>/config/easybot/config.json` 的 `token` ✓（两端必须一致 ✗）
3. 重启 MC 服（插件的 ws 握手用这个令牌）✓ → 日志出现「**鉴权成功!**」就是通了 ✓
4. 顺手把新令牌加进发布包的 `EXTRA_SECRET_PATTERNS` ✓（防止打进 zip ✗）

注意：这些文件多是 `root:root` ✗，普通用户改不了 → 用一次性 root 容器 ✓
```bash
docker run --rm -u 0 -v /data:/data -v /tmp:/hosttmp python:3.11-slim-bookworm \
  python3 /hosttmp/rotate.py "<新令牌>" "<旧令牌>"
```

### 9.7.7 "用 EB 自己重启 MC 服"的正解：**发 stop + start.sh 监督循环** ✓

EasyBot **没有** restart/start API ✗（`sessions` 只有 IsAlive/ServerExists/Remove/GetBridge/GetSessions/GetBridges，
`Bridge` 只有 GetServerInfo/GetPlayerListAsync/SendRunCommandAsync/…）。MCSManager 10.15 的 OpenAPI 也只有
`/api/overview`、`/api/files/status` 两个只读接口 ✗（它的 API 密钥存在 **用户记录 JSON 的 `apiKey` 字段**里，
可以自己生成写入 + 重启面板生效 ✓，但没实例控制接口还是没用 ✗）。

**正解**：
```bash
# start.sh 改成监督循环（正常退出 0 → 自动重开；异常退出最多连续 3 次）
while true; do
  java ... -jar fabric-server-mc*.jar nogui
  CODE=$?
  [ "$CODE" = "0" ] && { echo "[supervisor] 重开"; sleep 2; continue; }
  COUNT=$((COUNT+1)); [ "$COUNT" -gt 3 ] && exit "$CODE"; sleep 10
done
```
插件侧：管理员确认后 `bridge.SendRunCommandAsync('EasyBot', 'stop', false)` ✓（**直接调 Bridge，绕过指令黑名单** ✓，
但必须挂在管理员确认后面 ✓）。实测：stop → 22 秒后 `Done (2.150s)` ✓ 端口恢复 ✓。

两个坑：
- `stop` 在插件**指令硬黑名单**里 ✗ → 走 `eb_run_command` 永远被拒（`neededLevel: 99`）✗，必须直调 Bridge ✓
- 找服务器**不能用** `GetServerInfo().ServerName` ✗（返回 `"Fabric"` 模组名 ✗）
  → 用 `bridge.Session.Info.CachedServerName` ✓（EasyBot 里登记的名字，如 "创造服" ✓）

### 9.7.8 多台服"共用同一个 token" -> 全被识别成同一台 ✗

实测：`/data/riyue-survival` 的 `config/easybot/config.json` 里 token 与 **另一台服（日月妙妙屋）** 完全相同 ✗
→ EasyBot 里两台服务器**抢占同一个身份** ✗ → 界面上只剩一个名字（"日月妙妙屋 1.21.11"，其实就是生存服 ✗），
而"生存服"在 `ServerInfo` 里根本不存在 ✗ → 插件按名字找服务器当然找不到 ✗

**排查口诀**：把每台服的 `config.json` token 和 `ServerInfo.Token` 做一次对照表 ✓
```bash
for d in /data/riyue-*/config/easybot/config.json; do
  python3 -c "import json,sys;j=json.load(open('$d'));print('$d', j.get('token')[:8])"; done
```
**修法**：给缺身份的那台**新生成 token** ✓ + `ServerInfo` 插一行 ✓ + 写回它的 config.json ✓
→ EasyBot 的配置监听会**热重载**（`EasyBot-Config-Watcher`）✓，几十秒后日志出现 `"/生存服] 鉴权成功!` ✓
（改 DB 要 `docker stop easybot` 或用 root 容器写 ✓，文件是 root:root ✗）

### 9.7.9 服务器"卡在关闭中"：既不服务也不会重启 ✗

实测：`Stopping server` 之后 JVM 没退出（卡在某个 shutdown hook ✗）→ 端口还占着、EB 已判离线、
监督脚本也等不到退出码 ✗（等于半死 ✗）。处理：`kill -9 <java pid>` ✓ → 监督脚本走"崩溃重启"分支 ✓
（10 秒后重开 ✓）。排查用 `/proc/<pid>/stat` 的 state + starttime 算进程年龄 ✓。

### 9.7.10 换服务器 token 会打断 EasyBot 的**自定义指令**（"视奸/服务器状态"等）✗

EasyBot 的"自定义指令/图片指令"存在 `/app/appdata/dp/command.json` ✓，
结构大致：`{"Commands": {"<uuid>": {"CommandName": "玩家列表", "Scopes": [{"KeyWord": "视奸",
           "Servers": ["<serverToken>", …]}], "RunOptions": {"Commands":[{"Command":"list"}]}, "ImageMode": true}}}`
→ **关键词绑定的是 serverToken** ✗ → 一旦轮换 token，这些指令就"查不到服务器"，表现为**发关键词没反应** ✗

所以**换 token 时必须一起扫**：
```bash
grep -c "<旧token>" /app/appdata/dp/command.json   # 有命中就必须改
```
改法：JSON 解析 → 遍历 `Commands.*.Scopes[*].Servers` → 把旧 token 换成新 token → 写回 → **重启 EasyBot** ✓
（`command.json` 是 root:root ✗，用 `docker cp` 覆盖即可 ✓；改前先备份 ✓）

### 9.7.11 `while true; do java …` 监督循环会让 docker/面板【停不掉】✗✗

踩坑：为了让"EB 发 stop = 重启"，把 start.sh 改成 `while true; do java ...; done` ✓
→ 结果**面板/`docker stop` 关不掉** ✗：
- `bash` 是容器 PID 1，**不会把 SIGTERM 转发给 java** ✗ → `docker stop` 等 10 秒后 SIGKILL ✗
- 更糟：面板发 `stop` 指令 → java 正常退出(0) → 循环**又把它拉起来** ✗ → 永远停不下来 ✗

**正确写法**：信号感知 ✓
```bash
STOPPING=0; CHILD=""
on_term(){ STOPPING=1; echo "[supervisor] 停止信号 -> 转发 java 并停止重启"; [ -n "$CHILD" ] && kill -TERM "$CHILD" 2>/dev/null; }
trap on_term TERM INT
while true; do
  [ "$STOPPING" = "1" ] && exit 0
  java ... & CHILD=$!
  wait "$CHILD"; CODE=$?; CHILD=""
  [ "$STOPPING" = "1" ] && exit 0
  [ "$CODE" = "0" ] && { sleep 2; continue; }      # stop 指令 = 重启
  ...崩溃计数/退避...
done
```
实测：`kill -TERM 1`（等价 docker stop）→ 日志 `收到停止信号 -> 转发给 java，并且不再重启` ✓
→ 容器 `Exited (0)` 约 11 秒 ✓ 不再反复拉起 ✓

**纪律**：监督循环**只在真的需要**"用 stop 触发重启"的那台服上加 ✗
（原脚本就是单条 `java …` ✓ → java 退出 bash 就退出 ✓ → 面板/`docker stop` 天然能干净关 ✓
 别"顺手"给别的服也套上循环 ✗ —— 会把好端端的停止能力弄坏 ✗）

**另一个坑**：MCSManager 创建的容器是 **`--rm`** ✗ → 一次 `docker stop` 就把容器删掉 ✗（服务器直接消失 ✗）。
要自己重建时**故意不带 `--rm`** ✓；重建参数照抄实例配置（image / ports / networkMode / workingDir / env / startCommand）✓

### 9.8 运营
- 宿主机重启后要重新拉起桥接：`/home/user/dsh-bridge/start.sh`（配套 `stop.sh`）✓
- 健康检查：`curl -H "X-DSH-Token: <token>" http://127.0.0.1:PORT/health` ✓
- 容器 IP 变了不影响（插件连的是**网关**）；换网络/换端口时用插件命令改配置即可（`!dsh set baseUrl …`）✓
